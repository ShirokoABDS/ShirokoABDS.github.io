#version 330
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
in vec4 vertexColor;in vec2 dsCorner;in vec2 dsPosition;flat in vec2 dsUi;out vec4 fragColor;
const vec4 dsSizes[1]=vec4[1](vec4(329.0,179.0,5.0,10.0));
void main(){
    if(vertexColor.a==0.0)discard;
    if(all(greaterThan(vertexColor.rgb,vec3(.98)))&&vertexColor.a>.95){
        // Recover both local axes. Vertex batches may begin at any index modulo four.
        vec2 cx=dFdx(dsCorner),cy=dFdy(dsCorner),px=dFdx(dsPosition),py=dFdy(dsPosition);
        float determinant=cx.x*cy.y-cx.y*cy.x;
        if(abs(determinant)>.00000001){
            vec2 axisX=(px*cy.y-py*cx.y)/determinant;
            vec2 axisY=(py*cx.x-px*cy.x)/determinant;
            vec2 size=abs(axisX)+abs(axisY);
            for(int i=0;i<1;i++){
                vec2 w=dsSizes[i].xy;
                // The reference pack also filters dimensions rather than predicted centers.
                // Keep the whitelist tied to this export; do not hide every white GUI line.
                bool horizontal=abs(size.x-w.x)<1.25&&abs(size.y-1.0)<.25;
                bool vertical=abs(size.x-1.0)<.25&&abs(size.y-(w.y-2.0))<1.25;
                if(horizontal||vertical)discard;
            }
        }
    }
    fragColor=vertexColor*ColorModulator;
}