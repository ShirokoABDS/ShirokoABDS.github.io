#version 330
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {mat4 ProjMat;};
in vec3 Position;in vec4 Color;out vec4 vertexColor;out vec2 dsCorner;out vec2 dsPosition;flat out vec2 dsUi;
void main(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);vertexColor=Color;vec2 logical=abs(vec2(2.0/ProjMat[0][0],2.0/ProjMat[1][1]));dsUi=ceil(logical-vec2(.01));dsPosition=(gl_Position.xy/gl_Position.w*vec2(1.0,-1.0)+1.0)*logical*0.5;int c=gl_VertexID&3;dsCorner=vec2(c>=2?1.0:0.0,(c==1||c==2)?1.0:0.0);}