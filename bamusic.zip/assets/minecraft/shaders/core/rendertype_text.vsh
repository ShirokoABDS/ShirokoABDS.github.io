#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

uniform sampler2D Sampler0;
out vec2 dsHoverUV;
flat out vec4 dsHoverRect;
flat out vec4 dsHoverColor;
flat out vec4 dsHoverStyle;
flat out vec4 dsHoverFill;
flat out vec4 dsHoverArtwork;
flat out vec4 dsTooltipRect;
flat out int dsHover;
ivec4 dsPixel(ivec2 p){return ivec4(round(texelFetch(Sampler0,p,0)*255.0));}
float dsValue(ivec2 p){ivec4 v=dsPixel(p);return float(v.r+(v.g<<8));}

void main(){
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

texCoord0=UV0;dsHover=0;dsHoverUV=vec2(0.0);dsHoverRect=vec4(0.0);dsHoverColor=vec4(0.0);dsTooltipRect=vec4(0.0);dsHoverStyle=vec4(1.0,0.12,0.95,0.0);dsHoverFill=vec4(0.0);dsHoverArtwork=vec4(0.0);
if(abs(ProjMat[3][3]-1.0)<0.0001) {
    // Only our reserved-color glyph may read metadata. Glyph atlas placement and
    // vertex IDs can change between batches, so find the signed UV corner itself.
    ivec2 atlas=textureSize(Sampler0,0),uv=ivec2(round(UV0*vec2(atlas))),cell=ivec2(-1);
    vec2 corner=vec2(0.0);
    if(all(lessThan(abs(Color.rgb*255.0-vec3(19,137,211)),vec3(0.5)))) {
        for(int format=0;format<3;format++)for(int cy=0;cy<2;cy++)for(int cx=0;cx<2;cx++) {
            int cellSize=format==0?16:format==1?256:512;
            ivec2 candidate=uv-ivec2(cx,cy)*cellSize;
            if(all(greaterThanEqual(candidate,ivec2(0)))&&all(lessThanEqual(candidate+cellSize,atlas))
                &&all(equal(dsPixel(candidate),ivec4(19,137,211,255)))
                &&all(equal(dsPixel(candidate+ivec2(1,0)),ivec4(223,41,157,255)))
                &&all(equal(dsPixel(candidate+ivec2(cellSize-1)),ivec4(19,137,211,255)))) {
                cell=candidate;corner=vec2(cx,cy);
            }
        }
    }
    if(cell.x>=0){
        dsHover=1;
        vec2 canvas=vec2(dsValue(cell+ivec2(0,1)),dsValue(cell+ivec2(1,1)));
        vec2 xy=vec2(dsValue(cell+ivec2(2,1)),dsValue(cell+ivec2(3,1)));
        vec2 size=vec2(dsValue(cell+ivec2(4,1)),dsValue(cell+ivec2(5,1)));
        vec2 ui=ceil(abs(vec2(2.0/ProjMat[0][0],2.0/ProjMat[1][1]))-vec2(.01));
        dsHoverUV=corner;dsHoverRect=vec4(xy,size);dsHoverColor=vec4(dsPixel(cell+ivec2(6,1)))/255.0;dsHoverFill=dsHoverColor;
        ivec4 effect=dsPixel(cell+ivec2(11,1));if(effect.a==255){dsHoverStyle=vec4(float(effect.r),float(effect.g)/255.0,float(effect.b)/255.0,0.0);dsHoverFill=vec4(dsPixel(cell+ivec2(12,1)))/255.0;}
        ivec4 artwork=dsPixel(cell+ivec2(13,1));if(artwork.a==255){if(artwork.b==1)dsHoverArtwork=vec4(vec2(cell+ivec2(0,16)),vec2(artwork.rg));else if(artwork.b==2)dsHoverArtwork=vec4(vec2(cell+ivec2(0,16)),dsValue(cell+ivec2(14,1)),dsValue(cell+ivec2(15,1)));}
        dsTooltipRect=vec4(Position.xy-corner-vec2(3.0,9.0),dsValue(cell+ivec2(7,1)),dsValue(cell+ivec2(8,1)));
        // The fully visible, canvas-only compact Dialog has fixed native padding.
        // Scrolled/clipped canvases retain their ordinary tooltip without an overlay.
        float footer=dsValue(cell+ivec2(9,1)),tail=dsValue(cell+ivec2(10,1));
        if(ui.x<canvas.x+9.0||ui.y<canvas.y+41.0+footer+tail){gl_Position=vec4(2.0,2.0,2.0,1.0);}
        else {
            vec2 origin=vec2(floor((ui.x-canvas.x-9.0)*0.5)+4.0,min(63.0,max(33.0,ui.y-canvas.y-8.0-footer-tail))+3.0);
            vec2 target=origin+xy+corner*size;
            dsHoverRect.xy+=origin;
            vec4 old=ModelViewMat*vec4(Position,1.0);
            gl_Position=ProjMat*vec4(target,old.z,1.0);
            // GUI text has no depth test. Preserve its clip depth: moving below
            // zero clips the entire marker on zero-to-one rendering backends.
        }
    }
}
}
