#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

in vec2 dsHoverUV;
flat in vec4 dsHoverRect;
flat in vec4 dsHoverColor;
flat in vec4 dsHoverStyle;
flat in vec4 dsHoverFill;
flat in vec4 dsHoverArtwork;
flat in vec4 dsTooltipRect;
flat in int dsHover;

void main(){
    if(dsHover==1){
        vec2 pixel=dsHoverRect.xy+dsHoverUV*dsHoverRect.zw;
        if(all(greaterThanEqual(pixel,dsTooltipRect.xy))&&all(lessThan(pixel,dsTooltipRect.xy+dsTooltipRect.zw)))discard;
        if(dsHoverArtwork.z>0.0){
            ivec2 artPixel=ivec2(dsHoverArtwork.xy)+ivec2(clamp(floor(dsHoverUV*dsHoverArtwork.zw+vec2(.0001)),vec2(0.0),dsHoverArtwork.zw-vec2(1.0)));
            fragColor=texelFetch(Sampler0,artPixel,0);if(fragColor.a<0.1)discard;return;
        }
        vec2 edge=min(dsHoverUV,vec2(1.0)-dsHoverUV)*dsHoverRect.zw;
        bool border=min(edge.x,edge.y)<dsHoverStyle.x;
        fragColor=border?vec4(dsHoverColor.rgb,dsHoverStyle.z*dsHoverColor.a):vec4(dsHoverFill.rgb,dsHoverStyle.y*dsHoverFill.a);return;
    }

    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
